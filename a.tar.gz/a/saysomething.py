import libsay

print("In python")
strng = "Ahhhhhhhhh shit"
x = 2
y = 3
libsay.saySomething(x,y)

print("back to python")
