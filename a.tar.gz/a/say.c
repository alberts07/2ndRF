
#include <Python.h>

static PyObject* saySomething(PyObject* self, PyObject* args){
  // onoff is the toggle value for what ever switch is getting switched
  // int onoff = 0;

  int x, y;
  // int word;
  if (!PyArg_ParseTuple(args, "ii", &x, &y)) {
    return NULL;
  }

  printf("This is a C function was passed...%d and %d\n", x, y);
  return Py_None;//Py_BuildValue("s","hello");
}

static PyMethodDef SayMethods[] =
{
  {"saySomething", saySomething, METH_VARARGS, "Pass a number."},
  {NULL, NULL, 0, NULL}
};

PyMODINIT_FUNC initlibsay(void) {
  (void) Py_InitModule("libsay", SayMethods);
}
