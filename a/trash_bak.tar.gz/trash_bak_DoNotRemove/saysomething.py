import libsay

print("In python")

libsay.saySomething(1,1)

libsay.saySomething(1,0)
print("back to python")
