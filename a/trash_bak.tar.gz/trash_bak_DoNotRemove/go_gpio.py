import libgpio

print("In python")

libsay.gpioswitch(1,1)

libsay.gpioswitch(1,0)
print("back to python")
